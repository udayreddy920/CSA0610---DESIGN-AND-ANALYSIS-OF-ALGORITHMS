# CO1 – Scalability Audit of ShopSphere

**Course:** CSA06 – Design and Analysis of Algorithms  
**Assessment:** CO1 – Assessment Tool 1  
**Language:** Python 3

## Objective
Analyse five e-commerce back-end modules using operation counts, asymptotic notation, substitution, and the Master Theorem.

## Modules
1. M1 – Duplicate-Listing Detector
2. M2 – API Rate Limiter
3. M3 – Sequential and Binary Product Search
4. M4 – Recommendation Engine (current and redesigned)
5. M5 – Sales Analytics and nightly report generator

## Files
- `Python_Code.py` – formula calculations and scalability estimates
- `Solution.pdf` – worked answers for parts (a)–(g)
- `Report.pdf` – engineering findings and recommendations
- `Scalability_Results.csv` – calculated estimates for multiple input sizes
- `Output.png` – screenshot-style image of the program output
- `Output.txt` – raw console output

## Run
```bash
python Python_Code.py
```
The code uses only the Python standard library.

## Server assumption
The assignment specifies 10^8 basic operations per second. Time estimates are operation counts divided by 100,000,000. These are theoretical estimates, not production benchmarks.

**Remember:** Upload your original question paper separately as `Problem.pdf` if required by your faculty.
